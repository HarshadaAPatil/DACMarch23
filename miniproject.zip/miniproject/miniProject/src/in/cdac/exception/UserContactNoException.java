package in.cdac.exception;

@SuppressWarnings("serial")
public class UserContactNoException extends Exception{
	public UserContactNoException(String msg) {
		super(msg);
	}
}
